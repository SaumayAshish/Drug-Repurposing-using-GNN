import pandas as pd
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.fundamentaldata import FundamentalData
from src.config import ALPHA_VANTAGE_API_KEY
import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AlphaVantageClient:
    def __init__(self):
        if not ALPHA_VANTAGE_API_KEY:
            raise ValueError("ALPHA_VANTAGE_API_KEY not set.")
        self.ts = TimeSeries(key=ALPHA_VANTAGE_API_KEY, output_format='pandas')
        self.fd = FundamentalData(key=ALPHA_VANTAGE_API_KEY, output_format='pandas')

    def get_daily_prices(self, symbol, outputsize='full'):
        """
        Fetch daily adjusted time series data using yfinance (more reliable free tier).
        Returns DataFrame with columns: Open, High, Low, Close, Adj Close, Volume
        """
        try:
            logger.info(f"Fetching daily prices for {symbol} via yfinance...")
            import yfinance as yf
            
            # period='max' for full, '1y' for compact approximately
            period = 'max' if outputsize == 'full' else '1y'
            
            # yfinance download
            df = yf.download(symbol, period=period, progress=False)
            
            if df.empty:
                logger.warning(f"No data found for {symbol}")
                return None
            
            # Flatten columns if MultiIndex (common in recent yfinance)
            if isinstance(df.columns, pd.MultiIndex):
                # If ticker level exists, drop it
                if 'Ticker' in df.columns.names:
                    df = df.xs(symbol, axis=1, level='Ticker')
                # Or just select columns if flat
            
            # yfinance columns are Open, High, Low, Close, Adj Close, Volume already
            # Ensure naming
            df = df.rename(columns={
                'Adj Close': 'Adj Close'
            })
            
            # Ensure columns exist
            required = ['Open', 'High', 'Low', 'Close', 'Volume']
            if not all(col in df.columns for col in required):
                # Try to map if names differ
                logger.warning(f"Columns missing in yfinance data: {df.columns}")
            
            if 'Adj Close' not in df.columns and 'Close' in df.columns:
                 df['Adj Close'] = df['Close']

            return df
            
        except Exception as e:
            logger.error(f"Error fetching daily prices for {symbol}: {e}")
            return None

    def get_fundamental_overview(self, symbol):
        """Fetch company overview (PE, EPS, etc)."""
        try:
            logger.info(f"Fetching fundamental overview for {symbol}...")
            data, _ = self.fd.get_company_overview(symbol=symbol)
            return data
        except Exception as e:
            logger.error(f"Error fetching overview for {symbol}: {e}")
            return None

    def get_income_statement(self, symbol):
        try:
            logger.info(f"Fetching income statement for {symbol}...")
            data, _ = self.fd.get_income_statement(symbol=symbol)
            return data
        except Exception as e:
            logger.error(f"Error fetching income statement for {symbol}: {e}")
            return None
