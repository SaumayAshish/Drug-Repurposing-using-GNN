import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
ALPHA_VANTAGE_API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")

# Data Settings
TICKERS = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "SPY"] # Example tickers
TIMEFRAME = "daily"

# Model Settings
MODEL_TYPE = "xgboost" # or "lightgbm"
FORECAST_HORIZON = 30 # days

# Optimization Settings
RISK_FREE_RATE = 0.02 # Approximate default
