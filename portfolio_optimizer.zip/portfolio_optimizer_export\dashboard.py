import streamlit as st
import pandas as pd
import json
import os
import networkx as nx
import plotly.graph_objects as go
import plotly.express as px

# Set page config
st.set_page_config(page_title="AI Stock Intelligence (GNN + Quantum)", layout="wide")

# Load Results
def load_results():
    path = 'data/results/pipeline_output.json'
    if os.path.exists(path):
        with open(path, 'r') as f:
            return json.load(f)
    return None

st.title("AI-Driven Stock & Options Intelligence Platform")
st.markdown("Powered by **Graph Neural Networks** and **Quantum-Inspired Optimization**")

if st.button("Run Analysis Pipeline"):
    with st.spinner("Running AI Pipeline..."):
        from src.pipeline import run_pipeline
        run_pipeline()
    st.success("Analysis Complete!")
    # Reload results
    st.rerun()

results = load_results()

if results:
    # Funnel Metrics
    funnel = results.get('funnel', {})
    if funnel:
        st.markdown("### 🎯 Selection Funnel")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Universe Scanned", funnel.get('scanned', 0))
        c2.metric("Undervalued Found", funnel.get('undervalued', 0), help="Passed Fundamental & Technical Score")
        c3.metric("Daily Active", funnel.get('active_liquidity', 0), help="High Volume & Volatility")
        c4.metric("AI Selected", len(results.get('optimization', {})), help="Chosen by Quantum Optimizer")
        st.divider()

    tab1, tab2, tab3, tab4 = st.tabs(["🚀 Trading Signals", "🔍 Market Scanner", "🧠 GNN & AI Analysis", "⚡ Quantum Portfolio"])
    
    with tab2:
        st.header("🔍 Undervalued Stock Scanner")
        scanned = results.get('scanned_details', [])
        if scanned:
            df_scan = pd.DataFrame(scanned)
            st.dataframe(df_scan, use_container_width=True)
            st.caption("Stocks processing through the First Layer (Undervalued Filter)")
        else:
            st.info("No scanning data available. Run the pipeline.")

    with tab1:
        st.header("Real-time signals")
        signals = results.get('signals', [])
        
        if signals:
            for sig in signals:
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Ticker", sig['ticker'])
                with col2:
                    color = "green" if "BUY" in sig['signal'] else "red"
                    st.markdown(f"**Signal**: :{color}[{sig['signal']}]")
                    st.write(f"Confidence: {sig['confidence']:.2f}")
                with col3:
                    st.write(f"Strike: ${sig['suggested_strike']:.2f}")
                    st.write(f"Expiry: {sig['expiry']}")
                with col4:
                    st.metric("Projected Net Profit (100 shares)", f"${sig.get('projected_net_profit', 0):.2f}")
                
                st.divider()
        else:
            st.info("No actionable signals found.")

    with tab2:
        st.header("Graph Neural Network Analysis")
        gnn_scores = results.get('gnn_scores', {})
        
        if gnn_scores:
            # Influence Score Bar Chart
            df_gnn = pd.DataFrame(list(gnn_scores.items()), columns=['Ticker', 'Influence Score'])
            fig = px.bar(df_gnn, x='Ticker', y='Influence Score', color='Influence Score', title="Stock Influence Scores (GNN Output)")
            st.plotly_chart(fig, use_container_width=True)
            
            st.markdown("""
            **How it works:**
            The GNN constructs a graph where stocks are connected by correlation and sector. 
            It propagates information to find hidden undervaluation signals that isolated analysis might miss.
            """)
            
    with tab3:
        st.header("Quantum-Inspired Optimization (Simulated Annealing)")
        opt_weights = results.get('optimization', {})
        
        if opt_weights:
            st.markdown("**Objective**: Maximize Return - Risk - Cost - Correlation")
            fig = px.pie(values=list(opt_weights.values()), names=list(opt_weights.keys()), title="Optimal Allocation")
            st.plotly_chart(fig)
        else:
            st.info("Optimization yielded no results.")
else:
    st.warning("No results found. Please run the pipeline.")

