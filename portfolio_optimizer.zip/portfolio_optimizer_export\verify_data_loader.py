from src.data_loader import AlphaVantageClient
import sys
import os

# Add src to path
sys.path.append(os.getcwd())

def main():
    print("Initializing Client...")
    try:
        client = AlphaVantageClient()
    except Exception as e:
        print(f"Failed to init client: {e}")
        return

    print("Fetching AAPL prices...")
    df = client.get_daily_prices('AAPL', outputsize='compact')
    if df is not None:
        print("Successfully fetched prices:")
        print(df.head())
        print(f"Shape: {df.shape}")
    else:
        print("Failed to fetch prices.")

    print("\nFetching AAPL Overview...")
    overview = client.get_fundamental_overview('AAPL')
    if overview is not None:
        print("Successfully fetched overview:")
        print(overview.head() if hasattr(overview, 'head') else overview)
    else:
        print("Failed to fetch overview.")

if __name__ == "__main__":
    main()
