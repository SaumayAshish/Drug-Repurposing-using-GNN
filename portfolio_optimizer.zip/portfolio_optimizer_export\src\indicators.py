import pandas as pd
import numpy as np
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator

class IndicatorEngine:
    def __init__(self, data_engine):
        self.de = data_engine

    def get_technical_score(self, ticker, df=None):
        if df is None:
            df = self.de.get_daily_adjusted(ticker)
            
        if df is None or df.empty:
            return 0.0

        # Calculate Indicators
        # Normalize columns just in case
        close = df['Adj Close'] if 'Adj Close' in df.columns else df['Close']
        volume = df['Volume']
        
        # RSI
        rsi = RSIIndicator(close, window=14).rsi().iloc[-1]
        
        # MACD
        macd = MACD(close).macd_diff().iloc[-1]
        
        # 200 DMA
        dma200 = SMAIndicator(close, window=200).sma_indicator().iloc[-1]
        current_price = close.iloc[-1]
        
        # Score Logic
        score = 0
        
        # RSI Logic (Undervalued zone 30-45)
        if 30 <= rsi <= 45:
            score += 0.4
        elif rsi < 30:
            score += 0.5 # Deeply undervalued
            
        # MACD Logic (Bullish crossover proxy: positive histogram)
        if macd > 0:
            score += 0.3
            
        # DMA Logic (Price near support, say within 5% of 200 DMA)
        if dma200 > 0 and 0.95 <= (current_price / dma200) <= 1.05:
            score += 0.3
            
        return min(score, 1.0) # Cap at 1.0

    def get_fundamental_score(self, ticker):
        data = self.de.get_fundamentals(ticker)
        if not data:
            return 0.0
        
        score = 0
        try:
            # Parse values (handling errors/None)
            pe = float(data.get('PERatio', 0) or 100)
            peg = float(data.get('PEGRatio', 0) or 100)
            pb = float(data.get('PriceToBookRatio', 0) or 100)
            
            # Simple Rules
            if 0 < pe < 20: score += 0.4
            if 0 < peg < 1.0: score += 0.3
            if 0 < pb < 3.0: score += 0.3
            
        except:
            pass
            
        return min(score, 1.0)

    def get_undervalued_score(self, ticker, df=None):
        tech_score = self.get_technical_score(ticker, df=df)
        fund_score = self.get_fundamental_score(ticker)
        
        # Weighted Score
        final_score = (0.4 * tech_score) + (0.6 * fund_score)
        return final_score

    def check_liquidity_filter(self, ticker):
        df = self.de.get_daily_adjusted(ticker)
        if df is None: return False
        
        avg_volume = df['Volume'].rolling(20).mean().iloc[-1]
        
        # Threshold: e.g., 500k shares avg daily
        return avg_volume > 500000
