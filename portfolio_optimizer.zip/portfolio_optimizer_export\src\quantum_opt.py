import numpy as np
import random
import math

class QuantumOptimizer:
    def __init__(self, tickers, returns_vector, cov_matrix):
        """
        tickers: List of ticker symbols
        returns_vector: Expected returns (numpy array)
        cov_matrix: Covariance matrix (numpy array)
        """
        self.tickers = tickers
        self.mu = returns_vector
        self.S = cov_matrix
        self.num_assets = len(tickers)

    def objective_function(self, weights):
        """
        Maximize: Return - Risk - Penalty (for constraints)
        We want to maximize Sharpe-like metric essentially.
        """
        # Portfolio Return
        port_return = np.dot(weights, self.mu)
        
        # Portfolio Variance (Risk)
        port_var = np.dot(weights.T, np.dot(self.S, weights))
        port_vol = np.sqrt(port_var)
        
        # Penalty for constraints (e.g., weights sum to 1, sparsity)
        # We enforce sum=1 roughly by normalization in the step, but let's add penalty
        penalty = 0
        if abs(np.sum(weights) - 1.0) > 0.01:
            penalty += 100 * abs(np.sum(weights) - 1.0)
            
        # Objective: Maximize Return - lambda * Risk
        # Using lambda=0.5 for risk aversion
        score = port_return - 0.5 * port_vol - penalty
        return score

    def simulated_annealing(self, max_iter=1000, initial_temp=10.0, cooling_rate=0.95):
        """
        Simulates Quantum Annealing process.
        """
        # Random initial state (weights)
        current_weights = np.random.random(self.num_assets)
        current_weights /= np.sum(current_weights)
        
        current_score = self.objective_function(current_weights)
        
        best_weights = current_weights.copy()
        best_score = current_score
        
        temp = initial_temp
        
        for i in range(max_iter):
            # Neighbor: perturb weights slightly
            neighbor_weights = current_weights + np.random.normal(0, 0.05, self.num_assets)
            neighbor_weights = np.maximum(neighbor_weights, 0) # Non-negative
            neighbor_weights /= np.sum(neighbor_weights) # Normalize
            
            neighbor_score = self.objective_function(neighbor_weights)
            
            # Acceptance Probability
            delta = neighbor_score - current_score
            
            if delta > 0:
                # Accept better solution
                current_weights = neighbor_weights
                current_score = neighbor_score
                if current_score > best_score:
                    best_score = current_score
                    best_weights = current_weights
            else:
                # Accept worse solution with probability depending on Temp
                prob = math.exp(delta / temp)
                if random.random() < prob:
                    current_weights = neighbor_weights
                    current_score = neighbor_score
            
            # Cool down
            temp *= cooling_rate
            
        # Return simplified selection (Top N stocks)
        # Threshold: weights > 0.01
        selection = {}
        for idx, w in enumerate(best_weights):
            if w > 0.01:
                selection[self.tickers[idx]] = float(w)
                
        return selection, best_score

if __name__ == "__main__":
    # Test
    n = 5
    tickers = ['A', 'B', 'C', 'D', 'E']
    mu = np.array([0.1, 0.12, 0.15, 0.09, 0.05])
    S = np.eye(n) * 0.04 # 20% vol squared
    
    qo = QuantumOptimizer(tickers, mu, S)
    weights, score = qo.simulated_annealing()
    
    print("Optimized Selection:")
    print(weights)
