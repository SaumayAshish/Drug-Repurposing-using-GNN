import numpy as np
class CostCalculator:
    def __init__(self, broker='zerodha_us'):
        self.broker = broker

    def calculate_charges(self, buy_price, sell_price, quantity, is_intraday=False):
        """
        Calculates approximate charges (Brokerage, STT, Exchange, GST)
        Note: Rules vary significantly by broker and asset class.
        This provides a conservative estimate.
        """
        turnover = (buy_price + sell_price) * quantity
        profit_gross = (sell_price - buy_price) * quantity
        
        # Example Fee Structure (Hypothetical US via Indian Broker)
        # Brokerage: often flat fee (e.g., $3) or fraction
        brokerage = 0.0
        if self.broker == 'zerodha_us': 
            # Vested/Zerodha partnership usually charges flat fee or small cents/share?
            # Let's assume a generic small fee model typical for US investing from India
            brokerage = 0.0 # Many now zero commission, but let's say $0 for stocks
            
        exchange_txn_charge = 0.00002 * turnover # Exchange fees (very small)
        stt = 0 # No STT on US stocks usually for foreign investors directly, but depends on structure
        
        total_charges = brokerage + exchange_txn_charge
        
        if total_charges < 0: total_charges = 0
        
        net_profit = profit_gross - total_charges
        return net_profit, total_charges

class OptionsEngine:
    def __init__(self, indicator_engine):
        self.ie = indicator_engine

    def generate_signal(self, ticker, current_price):
        # 1. Market/Stock Bias
        u_score = self.ie.get_undervalued_score(ticker)
        
        signal = "HOLD"
        confidence = 0.0
        
        if u_score > 0.7:
            signal = "BUY_CALL"
            confidence = u_score
        elif u_score < 0.3:
            signal = "BUY_PUT" # Or short
            confidence = 1.0 - u_score
            
        # 2. Option Selection (Generic)
        # We don't have live option chain, so we return logic
        strike = np.round(current_price, 1)
        if signal == "BUY_CALL":
            # Slightly OTM or ATM
            strike = current_price * 1.02
        elif signal == "BUY_PUT":
            strike = current_price * 0.98
            
        return {
            "ticker": ticker,
            "signal": signal,
            "confidence": confidence,
            "suggested_strike": strike,
            "expiry": "Monthly" # Default recommendation
        }
    
    def simulate_trade(self, ticker, entry_price, exit_price, quantity):
        cc = CostCalculator()
        net, charges = cc.calculate_charges(entry_price, exit_price, quantity)
        return {
            "gross_profit": (exit_price - entry_price) * quantity,
            "charges": charges,
            "net_profit": net
        }
