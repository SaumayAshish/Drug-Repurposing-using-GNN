import os
import sys

# Ensure root is in path
sys.path.append(os.getcwd())

import pandas as pd
import time
from src.data_loader import AlphaVantageClient
from src.config import TICKERS

DATA_DIR = os.path.join(os.getcwd(), 'data', 'raw')
os.makedirs(DATA_DIR, exist_ok=True)

def fetch_all_data():
    client = AlphaVantageClient()
    
    for ticker in TICKERS:
        print(f"Processing {ticker}...")
        
        # 1. Fetch Daily Prices
        daily_file = os.path.join(DATA_DIR, f"{ticker}_daily.csv")
        if not os.path.exists(daily_file):
            # outputsize='compact' returns 100 data points. 'full' might be premium or failing.
            df = client.get_daily_prices(ticker, outputsize='compact')
            if df is not None:
                df.to_csv(daily_file)
                print(f"  Saved daily prices to {daily_file}")
            else:
                print(f"  Failed to fetch daily prices for {ticker}")
            # Rate limit handling (5 req/min free tier = 12s sleep)
            time.sleep(15) 
        else:
            print(f"  Daily prices already exist for {ticker}")

        # 2. Fetch Fundamental Overview
        overview_file = os.path.join(DATA_DIR, f"{ticker}_overview.json")
        if not os.path.exists(overview_file):
            overview = client.get_fundamental_overview(ticker)
            if overview is not None:
                if isinstance(overview, pd.DataFrame):
                    overview.to_json(overview_file, orient='records', lines=True)
                else:
                     # It might be a dict or dataframe depending on alpha_vantage version
                    pd.DataFrame([overview]).to_json(overview_file)
                print(f"  Saved overview to {overview_file}")
            else:
                 print(f"  Failed to fetch overview for {ticker}")
            time.sleep(15)
        else:
             print(f"  Overview already exist for {ticker}")

if __name__ == "__main__":
    fetch_all_data()
