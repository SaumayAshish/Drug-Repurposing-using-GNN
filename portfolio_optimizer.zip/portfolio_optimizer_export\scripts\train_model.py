import os
import json
import sys

# Ensure root is in path
sys.path.append(os.getcwd())

import pandas as pd
import numpy as np
from src.models import ReturnPredictor
from sklearn.model_selection import train_test_split

PROCESSED_DIR = os.path.join(os.getcwd(), 'data', 'processed')
RESULTS_DIR = os.path.join(os.getcwd(), 'data', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

def load_data():
    files = [f for f in os.listdir(PROCESSED_DIR) if f.endswith('_processed.csv')]
    data = {}
    for file in files:
        ticker = file.replace('_processed.csv', '')
        df = pd.read_csv(os.path.join(PROCESSED_DIR, file), index_col=0, parse_dates=True)
        data[ticker] = df
    return data

def train_xgboost():
    data = load_data()
    if not data:
        print("No processed data found.")
        return

    print(f"Training XGBoost on {len(data)} tickers...")
    
    predictor = ReturnPredictor(model_type='xgboost')
    
    predictor = ReturnPredictor(model_type='xgboost')
    
    overall_mse = []
    feature_importance = {}
    
    for ticker, df in data.items():
        print(f"  Training for {ticker}...")
        
        # Features & Target
        # Target: Target_Return_1d
        # Features: RSI, MACD, etc. Drop NaN.
        df = df.dropna()
        
        if df.empty:
            print(f"    Skipping {ticker} (empty after dropna)")
            continue
            
        target_col = 'Target_Return_1d'
        
        # Exclude non-feature columns
        exclude = ['Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume', 'Dividend', 'Split', target_col, 'Target_Return']
        features = [c for c in df.columns if c not in exclude and not c.startswith('Target')]
        
        X = df[features]
        y = df[target_col]
        
        # Train/Test Split (Time Series)
        split = int(len(X) * 0.8)
        X_train, X_test = X.iloc[:split], X.iloc[split:]
        y_train, y_test = y.iloc[:split], y.iloc[split:]
        
        predictor.train(X_train, y_train)
        mse, preds = predictor.evaluate(X_test, y_test)
        
        print(f"    MSE: {mse:.6f}")
        overall_mse.append(mse)
        
        # Extract feature importance if available
        if hasattr(predictor.model, 'feature_importances_'):
            fi = dict(zip(features, predictor.model.feature_importances_.tolist()))
            # Sort by importance
            fi = dict(sorted(fi.items(), key=lambda item: item[1], reverse=True))
            feature_importance[ticker] = fi
        
    if overall_mse:
        print(f"Average MSE: {np.mean(overall_mse):.6f}")

    # Save feature importance
    with open(os.path.join(RESULTS_DIR, 'feature_importance.json'), 'w') as f:
        json.dump(feature_importance, f, indent=4)
    print(f"Feature importance saved to {os.path.join(RESULTS_DIR, 'feature_importance.json')}")

if __name__ == "__main__":
    train_xgboost()
