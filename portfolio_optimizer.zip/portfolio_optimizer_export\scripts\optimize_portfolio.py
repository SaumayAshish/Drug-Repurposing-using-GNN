from pypfopt import expected_returns, risk_models
import json
from pypfopt.efficient_frontier import EfficientFrontier
import pandas as pd
import os
import sys

# Ensure root is in path
sys.path.append(os.getcwd())

PROCESSED_DIR = os.path.join(os.getcwd(), 'data', 'processed')
RESULTS_DIR = os.path.join(os.getcwd(), 'data', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)

def load_prices():
    files = [f for f in os.listdir(PROCESSED_DIR) if f.endswith('_processed.csv')]
    prices = pd.DataFrame()
    for file in files:
        ticker = file.replace('_processed.csv', '')
        try:
            df = pd.read_csv(os.path.join(PROCESSED_DIR, file), index_col=0, parse_dates=True)
            # Use 'Adj Close'
            if 'Adj Close' in df.columns:
                prices[ticker] = df['Adj Close']
            elif 'Close' in df.columns:
                prices[ticker] = df['Close']
        except Exception as e:
            print(f"Error loading {ticker}: {e}")
            
    return prices

def optimize():
    prices = load_prices()
    if prices.empty:
        print("No price data found.")
        return

    print("Optimizing portfolio...")
    # Calculate expected returns and sample covariance
    # Using historical mean returns
    mu = expected_returns.mean_historical_return(prices)
    
    # Using sample covariance
    S = risk_models.sample_cov(prices)

    # Optimize for maximal Sharpe ratio
    ef = EfficientFrontier(mu, S)
    
    # Weights sum to 1, no shorting (default bounds=(0,1))
    weights = ef.max_sharpe()
    cleaned_weights = ef.clean_weights()
    
    print("\nOptimal Weights (Max Sharpe):")
    print(cleaned_weights)
    
    print("\nPerformance:")
    perf = ef.portfolio_performance(verbose=True)
    
    # Save results
    results = {
        "weights": cleaned_weights,
        "performance": {
            "expected_return": perf[0],
            "annual_volatility": perf[1],
            "sharpe_ratio": perf[2]
        }
    }
    
    with open(os.path.join(RESULTS_DIR, 'optimization_results.json'), 'w') as f:
        json.dump(results, f, indent=4)
        
    print(f"\nResults saved to {os.path.join(RESULTS_DIR, 'optimization_results.json')}")

if __name__ == "__main__":
    optimize()
