import pandas as pd
import numpy as np
import networkx as nx
import torch

class GraphBuilder:
    def __init__(self, data_engine):
        self.de = data_engine

    def build_graph(self, tickers, correlation_threshold=0.7):
        """
        Builds a graph where nodes are stocks and edges are correlations.
        Returns:
            features (Torch Tensor): Node features
            adj (Torch Tensor): Adjacency Matrix (Normalized)
        """
        # 1. Fetch Price Data for all tickers
        # This might be slow if fully live, so we rely on cached data
        prices = pd.DataFrame()
        for t in tickers:
            df = self.de.get_daily_adjusted(t)
            if df is not None and not df.empty:
                col = 'Adj Close' if 'Adj Close' in df.columns else 'Close'
                prices[t] = df[col]
        
        # Align dates
        prices = prices.apply(pd.to_numeric, errors='coerce')
        prices = prices.dropna()
        
        if prices.empty:
            return None, None, []
            
        # 2. Compute Correlations
        returns = prices.pct_change().dropna()
        corr_matrix = returns.corr()
        
        # 3. Build Adjacency Matrix
        # Create NetworkX graph
        G = nx.Graph()
        valid_tickers = prices.columns.tolist()
        G.add_nodes_from(valid_tickers)
        
        # Add edges based on correlation
        for i in range(len(valid_tickers)):
            for j in range(i + 1, len(valid_tickers)):
                t1 = valid_tickers[i]
                t2 = valid_tickers[j]
                corr = corr_matrix.loc[t1, t2]
                
                if abs(corr) > correlation_threshold:
                    G.add_edge(t1, t2, weight=abs(corr))
                    
        # Convert to Tensor
        # Get Adjacency Matrix
        adj = nx.to_numpy_array(G, nodelist=valid_tickers)
        adj_tensor = torch.FloatTensor(adj)
        
        # Normalize Adjacency (D^-0.5 * A * D^-0.5)
        # Add self-loops
        adj_tensor = adj_tensor + torch.eye(len(valid_tickers))
        
        degrees = adj_tensor.sum(dim=1)
        d_inv_sqrt = torch.diag(torch.pow(degrees, -0.5))
        # Handle infs
        d_inv_sqrt[torch.isinf(d_inv_sqrt)] = 0.
        
        adj_norm = torch.mm(torch.mm(d_inv_sqrt, adj_tensor), d_inv_sqrt)
        
        # 4. Build Features
        # For now, simplistic features: recent return, volatility
        features_list = []
        for t in valid_tickers:
            r = returns[t]
            recent_ret = r.iloc[-1]
            vol = r.std() * np.sqrt(252)
            features_list.append([recent_ret, vol])
            
        features_tensor = torch.FloatTensor(features_list)
        
        return features_tensor, adj_norm, valid_tickers
