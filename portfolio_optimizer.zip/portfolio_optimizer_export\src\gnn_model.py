import torch
import torch.nn as nn
import torch.nn.functional as F

# Placeholder for PyTorch Geometric if available, effectively implementing a basic GCN layer manually
# to avoid heavy dependency issues if user system has trouble with torch_geometric installation

class SimpleGCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(SimpleGCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x, adj):
        # x: (num_nodes, in_features)
        # adj: (num_nodes, num_nodes) - adjacency matrix with self-loops
        
        # Aggregation: A * X
        support = torch.mm(adj, x)
        
        # Transformation: (A * X) * W
        output = self.linear(support)
        
        return output

class StockGNN(nn.Module):
    def __init__(self, num_features, hidden_dim, output_dim):
        super(StockGNN, self).__init__()
        self.gc1 = SimpleGCNLayer(num_features, hidden_dim)
        self.gc2 = SimpleGCNLayer(hidden_dim, output_dim)
        self.dropout = 0.2

    def forward(self, x, adj):
        # x: Feature matrix (Num_Stocks x Num_Features)
        # adj: Adjacency matrix (Num_Stocks x Num_Stocks)
        
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        
        # Output is often a score or a latent representation
        # If we want a probability of "Undervalued", we pass through sigmoid
        return torch.sigmoid(x)

if __name__ == "__main__":
    # Test Dimensions
    num_stocks = 10
    num_features = 5
    hidden = 8
    
    # Random Features (e.g., P/E, RSI, Volatility...)
    features = torch.randn(num_stocks, num_features)
    
    # Random Adjacency (Binary correlation mask)
    adj = torch.eye(num_stocks) # Self loops
    adj[0, 1] = 1 # Connect stock 0 and 1
    adj[1, 0] = 1
    
    # Normalize Adj (simplified)
    deg = adj.sum(1)
    d_inv_sqrt = torch.diag(torch.pow(deg, -0.5))
    adj_norm = torch.mm(torch.mm(d_inv_sqrt, adj), d_inv_sqrt)
    
    model = StockGNN(num_features, hidden, 1)
    output = model(features, adj_norm)
    
    print("GNN Output (Influence/Undervalued Score):")
    print(output)
