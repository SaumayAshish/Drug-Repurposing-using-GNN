import os
import sys

# Add root to path if running as script
if __name__ == "__main__":
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import pandas as pd
import json
import numpy as np
import networkx as nx
from src.data_engine import DataEngine
from src.indicators import IndicatorEngine
from src.graph_builder import GraphBuilder
from src.gnn_model import StockGNN
from src.quantum_opt import QuantumOptimizer
from src.options_engine import OptionsEngine
from dotenv import load_dotenv

# Load Env
load_dotenv()
API_KEY = os.getenv('ALPHAVANTAGE_API_KEY', 'demo')

def run_pipeline():
    print("--- Starting AI-Driven Stock Intelligence Pipeline ---")
    
    # 1. Initialize Engines
    de = DataEngine(API_KEY)
    ie = IndicatorEngine(de)
    gb = GraphBuilder(de)
    oe = OptionsEngine(ie)
    
    # 2. Define Universe (S&P 500)
    # Fetch full list, but processing 500 stocks sequentially might take too long for a demo.
    # We'll take the first 50 for now to ensure we find enough candidates.
    full_list = de.get_sp500_tickers()
    tickers = full_list[:50] 
    print(f"Universe Size: {len(tickers)} (Processing subset for speed)")
    
    # 3. Data Acquisition & Initial Screening (Undervalued First)
    print("--- Step 1: Scanning for Undervalued Stocks ---")
    undervalued_candidates = []
    scanned_data = [] # NEW: Store details
    prices_map = {} 
    
    for t in tickers:
        df = de.get_daily_adjusted(t)
        if df is not None and not df.empty:
            try:
                # We need prices for technicals in undervalued score
                score = ie.get_undervalued_score(t, df=df)
                
                # Capture metrics for transparency regardless of pass/fail (or just pass?)
                # user wants "undervalued stocks" shown.
                
                if score >= 0.5:
                    undervalued_candidates.append(t)
                    prices_map[t] = df
                    
                    # Get Metrics for UI
                    last_price = df['Adj Close'].iloc[-1]
                    fund = de.get_fundamentals(t) or {}
                    tech_score = ie.get_technical_score(t, df=df)
                    
                    scanned_data.append({
                        "Ticker": t,
                        "Price": round(last_price, 2),
                        "Score": round(score, 2),
                        "TechScore": round(tech_score, 2),
                        "PE": fund.get('PERatio', 'N/A'),
                        "ROE": fund.get('ReturnOnEquityTTM', 'N/A')
                    })
            except Exception as e:
                print(f"Error scoring {t}: {e}")
                
    print(f"Undervalued Candidates: {len(undervalued_candidates)} / {len(tickers)}")
    print(f"List: {undervalued_candidates}")

    # 4. Daily Trading Filter (Liquidity)
    print("--- Step 2: Filtering for Daily Trading Activity ---")
    active_tickers = []
    prices_df = pd.DataFrame()
    
    for t in undervalued_candidates:
        # We already have the df, pass it check
        if ie.check_liquidity_filter(t):
            active_tickers.append(t)
            # Add to master DF for downstream (GNN/Quantum)
            # Force numeric already happening in DataEngine? No, we need to be safe
            col = 'Adj Close' if 'Adj Close' in prices_map[t].columns else 'Close'
            prices_df[t] = prices_map[t][col]

    # Force numeric for downstream math
    prices_df = prices_df.apply(pd.to_numeric, errors='coerce')
    prices_df = prices_df.dropna(axis=1, how='all')
    prices_df = prices_df.dropna()
    
    # Re-sync active_tickers with valid columns in prices_df
    active_tickers = [t for t in active_tickers if t in prices_df.columns]
    
    print(f"Active & Undervalued Tickers: {len(active_tickers)}")
    print(f"Final List for AI: {active_tickers}")
    
    if not active_tickers:
        print("No stocks passed all filters.")
        return

    # 5. GNN Analysis (Relationships)
    print("--- Step 3: GNN Relationship Analysis ---")
    features, adj, graph_tickers = gb.build_graph(active_tickers)
    
    gnn_scores = {}
    if features is not None and len(graph_tickers) > 0:
        model = StockGNN(num_features=features.shape[1], hidden_dim=8, output_dim=1)
        with torch.no_grad():
            output = model(features, adj) 
        for idx, t in enumerate(graph_tickers):
            gnn_scores[t] = float(output[idx].item())
    
    # Refine Scores with GNN influence
    final_scores = {}
    for t in active_tickers:
        # Recalculate base score to be sure, or cache it?
        # Let's just re-get basic score (cheap)
        base_score = 0
        if t in prices_map:
             base_score = ie.get_undervalued_score(t, df=prices_map[t])
             
        gnn_influence = gnn_scores.get(t, 0.5)
        # Hierarchy: Base (Undervalued) + Stock Bias (GNN)
        final_scores[t] = 0.6 * base_score + 0.4 * gnn_influence

    # 6. Quantum Optimization
    print("--- Step 4: Quantum-Inspired Optimization ---")
    returns = prices_df.pct_change().mean() * 252
    cov = prices_df.pct_change().cov() * 252
    
    # Optimize ALL filtered stocks (or top N if list is huge)
    qt_candidates = sorted(final_scores.keys(), key=lambda x: final_scores[x], reverse=True)
    # If list is too big for Simulated Annealing speed, limit to top 20? 
    # Current subset 50 -> filtered maybe 10-20. Safe to run all.
    
    qo = QuantumOptimizer(qt_candidates, returns[qt_candidates].values, cov.loc[qt_candidates, qt_candidates].values)
    optimized_weights, _ = qo.simulated_annealing()
    
    # 7. Hierarchical Option Strategy
    print("--- Step 5: Hierarchical Option Strategy ---")
    signals = []
    current_prices = prices_df.iloc[-1]
    
    for t in qt_candidates:
        if t in optimized_weights and optimized_weights[t] > 0.01:
            # Hierarchical Signal Generation
            # Level 1: Market (Implicitly done by picking S&P)
            # Level 2: Stock (GNN/Undervalued Score)
            # Level 3: Option Selection
            sig = oe.generate_signal(t, current_prices[t])
            
            sig['allocation_pct'] = optimized_weights[t]
            
            # Simulated Profit (inc overhead)
            cost_res = oe.simulate_trade(t, current_prices[t], current_prices[t]*1.15, 100) # Target 15% return
            sig['projected_net_return_15pct'] = cost_res['net_profit']
            
            signals.append(sig)
            
    # 8. Save Results
    results = {
        "timestamp": str(pd.Timestamp.now()),
        "funnel": {
            "scanned": len(tickers),
            "undervalued": len(undervalued_candidates),
            "active_liquidity": len(active_tickers)
        },
        "scanned_details": scanned_data, # NEW: Detailed metrics for dashboard
        "signals": signals,
        "gnn_scores": gnn_scores,
        "optimization": optimized_weights
    }
    
    os.makedirs('data/results', exist_ok=True)
    with open('data/results/pipeline_output.json', 'w') as f:
        json.dump(results, f, indent=4)
        
    print("Pipeline Complete. Results saved.")

if __name__ == "__main__":
    run_pipeline()
