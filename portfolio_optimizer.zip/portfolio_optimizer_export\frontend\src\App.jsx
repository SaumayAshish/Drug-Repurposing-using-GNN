import React from 'react';
import UndervaluedStockAnalyzer from './UndervaluedStockAnalyzer';

function App() {
  return (
    <UndervaluedStockAnalyzer />
  );
}

export default App;
