import xgboost as xgb
import lightgbm as lgb
from sklearn.metrics import mean_squared_error, accuracy_score
import numpy as np
import pandas as pd
import torch
import torch.nn as nn

class ReturnPredictor:
    def __init__(self, model_type='xgboost'):
        self.model_type = model_type
        self.model = None

    def train(self, X_train, y_train):
        """Train the regression model."""
        if self.model_type == 'xgboost':
            self.model = xgb.XGBRegressor(
                objective='reg:squarederror', 
                n_estimators=100, 
                learning_rate=0.1, 
                max_depth=5
            )
            self.model.fit(X_train, y_train)
        elif self.model_type == 'lightgbm':
            self.model = lgb.LGBMRegressor(
                n_estimators=100,
                learning_rate=0.1
            )
            self.model.fit(X_train, y_train)
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")

    def predict(self, X_test):
        if self.model is None:
            raise ValueError("Model not trained yet.")
        return self.model.predict(X_test)
    
    def evaluate(self, X_test, y_test):
        preds = self.predict(X_test)
        mse = mean_squared_error(y_test, preds)
        return mse, preds

class LSTMForecaster(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim=1, num_layers=2):
        super(LSTMForecaster, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # x shape: (batch_size, seq_length, input_dim)
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        
        out, _ = self.lstm(x, (h0, c0))
        # Take the last time step
        out = self.fc(out[:, -1, :])
        return out
