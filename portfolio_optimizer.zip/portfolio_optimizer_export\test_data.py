from src.data_engine import DataEngine
import pandas as pd
import os

key = 'demo'
de = DataEngine(key)

print("Testing Data Fetching...")
df = de.get_daily_adjusted('AAPL', force_refresh=True)

print(f"Type: {type(df)}")
if df is not None:
    print("Columns:", df.columns)
    print("Index:", df.index.dtype)
    print("Head:\n", df.head())
    print("Dtypes:\n", df.dtypes)
    
    # Check if we can do math
    try:
        print("Mean:", df['Close'].mean())
    except Exception as e:
        print(f"Math Error: {e}")
else:
    print("DF is None")
