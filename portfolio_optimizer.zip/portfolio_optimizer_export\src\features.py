import pandas as pd
import ta
import numpy as np

class FeatureEngineer:
    def __init__(self):
        pass

    def add_technical_indicators(self, df):
        """
        Adds RSI, MACD, Bollinger Bands, ATR, ADX, SMA, EMA.
        Expects columns: Open, High, Low, Close, Volume
        """
        df = df.copy()
        
        # Ensure correct types
        for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Fill NaNs if any after coercion
        df = df.dropna()

        # RSI
        df['RSI'] = ta.momentum.rsi(df['Close'], window=14)
        
        # MACD
        macd = ta.trend.MACD(df['Close'])
        df['MACD'] = macd.macd()
        df['MACD_Signal'] = macd.macd_signal()
        df['MACD_Diff'] = macd.macd_diff()
        
        # Bollinger Bands
        bb = ta.volatility.BollingerBands(df['Close'], window=20, window_dev=2)
        df['BB_High'] = bb.bollinger_hband()
        df['BB_Low'] = bb.bollinger_lband()
        df['BB_Width'] = (df['BB_High'] - df['BB_Low']) / df['Close']
        
        # ATR
        df['ATR'] = ta.volatility.average_true_range(df['High'], df['Low'], df['Close'], window=14)
        
        # ADX
        df['ADX'] = ta.trend.adx(df['High'], df['Low'], df['Close'], window=14)
        
        # SMA / EMA
        df['SMA_50'] = ta.trend.sma_indicator(df['Close'], window=50)
        df['EMA_20'] = ta.trend.ema_indicator(df['Close'], window=20)
        
        return df

    def add_risk_metrics(self, df):
        """
        Adds Rolling Volatility, Drawdown.
        """
        df = df.copy()
        
        # Daily Returns
        df['Returns'] = df['Close'].pct_change()
        
        # Rolling Volatility (21 days ~ 1 month)
        df['Rolling_Vol_21'] = df['Returns'].rolling(window=21).std() * np.sqrt(252)
        
        # Drawdown
        rolling_max = df['Close'].rolling(window=252, min_periods=1).max()
        df['Drawdown'] = (df['Close'] / rolling_max) - 1.0
        
        return df
    
    def prepare_for_model(self, df, target_horizon=1):
        """
        Creates lag features and target variable.
        Target: Future Return (N days ahead)
        """
        df = df.copy()
        
        # Calculate Target: Return N days ahead
        # We want to predict if price goes up/down or the magnitude
        # target_return = (Price[t+h] - Price[t]) / Price[t]
        df[f'Target_Return_{target_horizon}d'] = df['Close'].shift(-target_horizon) / df['Close'] - 1
        
        return df
