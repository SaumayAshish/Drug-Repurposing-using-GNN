import os
import sys

# Ensure root is in path
sys.path.append(os.getcwd())

import pandas as pd
from src.features import FeatureEngineer

RAW_DIR = os.path.join(os.getcwd(), 'data', 'raw')
PROCESSED_DIR = os.path.join(os.getcwd(), 'data', 'processed')
os.makedirs(PROCESSED_DIR, exist_ok=True)

def process_all_data():
    fe = FeatureEngineer()
    
    if not os.path.exists(RAW_DIR):
        print(f"Raw data directory {RAW_DIR} does not exist.")
        return

    files = [f for f in os.listdir(RAW_DIR) if f.endswith('_daily.csv')]
    
    if not files:
        print("No daily data files found.")
        return

    print(f"Found {len(files)} files to process.")
    
    for file in files:
        ticker = file.replace('_daily.csv', '')
        print(f"Processing {ticker}...")
        
        try:
            df = pd.read_csv(os.path.join(RAW_DIR, file), index_col=0, parse_dates=True)
            
            # Apply Technical Indicators
            df = fe.add_technical_indicators(df)
            
            # Apply Risk Metrics
            df = fe.add_risk_metrics(df)
            
            # Prepare for Model (Target)
            df = fe.prepare_for_model(df, target_horizon=1) # 1 day ahead return
            
            # Drop rows with NaN (due to rolling windows)
            df = df.dropna()
            
            output_file = os.path.join(PROCESSED_DIR, f"{ticker}_processed.csv")
            df.to_csv(output_file)
            print(f"  Saved processed data to {output_file}")
            
        except Exception as e:
            print(f"  Error processing {ticker}: {e}")

if __name__ == "__main__":
    process_all_data()
